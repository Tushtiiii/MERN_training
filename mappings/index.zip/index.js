const express = require('express');
const getCon = require('./config/connection');
const userRouter = require('./routers/userRouter');
const deviceRouter = require('./routers/deviceRouter');


const server = express();
server.use(express.json());
server.use('/user',userRouter);
server.use('/device', deviceRouter);

server.listen(8990,async() => {
    await getCon();
    console.log("Server is running on port 8990");
})
